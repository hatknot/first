a = input()

if(a):
	print(23)
else:
	print("nothing")
