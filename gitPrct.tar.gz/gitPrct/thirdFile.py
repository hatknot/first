a = input()

if(a):
	print(29)
else:
	print("nothing")
